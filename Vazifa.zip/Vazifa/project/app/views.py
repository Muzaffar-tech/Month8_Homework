from django.forms import model_to_dict
from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response

from .models import Category, Article, Comment

# Create your views here.

class CategoryApiView(APIView):
    def get(self, request: Request, pk=None):
        if not pk:
            list_category = []
            categoryies = Category.objects.all()
            for category in categoryies:
                list_category.append({
                    'id': category.id,
                    'name': category.name
                })

            return Response({'Categories': list_category})
        try:
            category = Category.objects.get(pk=pk)
            return Response(model_to_dict(category))
        except:
            return Response({'Error': 'Category not found'}, status=404)

class ArticleApiView(APIView):
    def get(self, request: Request, pk=None):
        if not pk:
            list_article = []
            articles = Article.objects.all()
            for article in articles:
                list_article.append({
                    'id' : article.id,
                    'title' : article.title,
                    'content' : article.content,
                    'date' : article.date,
                    'category' : article.category.id,
                    'author' : article.author
                })
            return Response({'Article': list_article})
        try:
            article = Article.objects.get(pk=pk)
            return Response(model_to_dict(article))
        except:
            return Response({'Error': 'Article not found'}, status=404)

class CommentApiView(APIView):
    def get(self, request: Request, pk=None):
        if not pk:
            list_comment = []
            comments = Comment.objects.all()
            for comment in comments:
                list_comment.append({
                    'id': comment.id,
                    'article': comment.article.id,
                    'username': comment.username,
                    'email':comment.email,
                    'content':comment.content,
                    'created_at':comment.created_at
                })

            return Response({'Comments': list_comment})
        try:
            comment = Comment.objects.get(pk=pk)
            return Response(model_to_dict(comment))
        except:
            return Response({'Error': 'Comment not found'}, status=404)



