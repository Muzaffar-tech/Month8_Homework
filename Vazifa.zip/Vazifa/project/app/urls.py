from django.urls import path
from .views import *

urlpatterns = [
    path('category/', CategoryApiView.as_view()),
    path('category/<int:pk>', CategoryApiView.as_view()),
    path('article/', ArticleApiView.as_view()),
    path('article/<int:pk>', ArticleApiView.as_view()),
    path('comment/', CommentApiView.as_view()),
    path('comment/<int:pk>', CommentApiView.as_view()),
]